function setBackground() {
  $("[setBackground]").each(function() {
    var background = $(this).attr("setBackground");
    $(this).css({
      "background-image": "url(" + background + ")",
      "background-size": "cover",
      "background-position": "center center"
    });
  });
  $("[setBackgroundRepeat]").each(function() {
    var background = $(this).attr("setBackgroundRepeat");
    $(this).css({
      "background-image": "url(" + background + ")",
      "background-repeat": "repeat"
    });
  });
}

function searchshow() {
  $(".button-search").on("click", function() {
    $(".searchbox").toggleClass("active");
  });
}
// Mobile Toggle

function mobileToggle() {
  $("header .mobile-toggle em").on("click", function() {
    $(".mobile-wrapper").toggleClass("active");
  });
}

function swiperInit() {
  var partnerSwiper = new Swiper(".partnet-swiper-wrapper .swiper-container", {
    // Optional parameters
    loop: true,
    autoplay: {
      delay: 2500
    },
    breakpointsInverse: true,
    breakpoints: {
      // when window width is >= 320px
      320: {
        slidesPerView: 2,
        spaceBetween: 20
      },
      576: {
        slidesPerView: 3,
        spaceBetween: 20
      },
      768: {
        slidesPerView: 4,
        spaceBetween: 20
      },
      // when window width is >= 480px
      1025: {
        slidesPerView: 5
      },
      // when window width is >= 640px
      1441: {
        slidesPerView: 6,
        spaceBetween: 20
      }
    },
    speed: 1250,
    navigation: {
      nextEl: ".navigation-partner-next",
      prevEl: ".navigation-partner-prev"
    }
  });
  var swiperHomeSlide = new Swiper(".home-slider1 .swiper-container", {
    autoplay: {
      delay: 4000,
      speed: 1000
    }
  });
  var swiperBusiness = new Swiper(".business .swiper-container", {
    slidesPerView: 5,
    spaceBetween: 15,
    navigation: {
      nextEl: ".business-button-next",
      prevEl: ".business-button-prev"
    },
    // autoplay: {
    //     delay: 3000,
    //     disableOnInteraction: false,
    // },
    breakpoints: {
      // when window width is <= 480px
      480: {
        slidesPerView: 1,
        spaceBetween: 20
      },
      // when window width is <= 640px
      768: {
        slidesPerView: 2,
        spaceBetween: 30
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 30
      },
      1025: {
        slidesPerView: 4,
        spaceBetween: 30
      }
    }
  });
  var swiperSlide2 = new Swiper(".product-slider2 .swiper-container", {
    slidesPerView: 4,
    spaceBetween: 15,
    navigation: {
      nextEl: ".product-button-next",
      prevEl: ".product-button-prev"
    },
    // autoplay: {
    //     delay: 3000,
    //     disableOnInteraction: false,
    // },
    breakpoints: {
      // when window width is <= 480px
      480: {
        slidesPerView: 1,
        spaceBetween: 20
      },
      // when window width is <= 640px
      768: {
        slidesPerView: 2,
        spaceBetween: 30
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 30
      },
      1025: {
        slidesPerView: 4,
        spaceBetween: 30
      }
    }
  });
  var swiper = new Swiper(".home-project .swiper-container", {
    slidesPerView: 4,
    spaceBetween: 15,
    navigation: {
      nextEl: ".project-button-next",
      prevEl: ".project-button-prev"
    },
    // autoplay: {
    //     delay: 3000,
    //     disableOnInteraction: false,
    // },
    breakpoints: {
      // when window width is <= 480px
      480: {
        slidesPerView: 1,
        spaceBetween: 20
      },
      // when window width is <= 640px
      768: {
        slidesPerView: 2,
        spaceBetween: 30
      },
      992: {
        slidesPerView: 2,
        spaceBetween: 30
      },
      1025: {
        slidesPerView: 3,
        spaceBetween: 30
      }
    }
  });
  var swiper = new Swiper(".home-news .swiper-container", {
    slidesPerView: 4,
    spaceBetween: 15,
    navigation: {
      nextEl: ".news-button-next",
      prevEl: ".news-button-prev"
    },
    // autoplay: {
    //     delay: 3000,
    //     disableOnInteraction: false,
    // },
    breakpoints: {
      // when window width is <= 480px
      480: {
        slidesPerView: 1,
        spaceBetween: 20
      },
      // when window width is <= 640px
      768: {
        slidesPerView: 2,
        spaceBetween: 30
      },
      992: {
        slidesPerView: 3,
        spaceBetween: 30
      },
      1025: {
        slidesPerView: 4,
        spaceBetween: 30
      }
    }
  });
    var swiper = new Swiper('.doitac-slider .swiper-container', {
      slidesPerView: 3,
      slidesPerColumn: 2,
      spaceBetween: 30,
      navigation: {
        nextEl: '.swiper-btnnext',
        prevEl: '.swiper-btnprev'
      },
      // autoplay: {
      //   delay: 3000,
      //   disableOnInteraction: false,
      // },
      // If we need pagination
      pagination: {
        el: '.home-slider .swiper-pagination',
        clickable: true,
        type: 'bullets'
      },
      breakpoints: {
        // when window width is <= 320px
        320: {
          slidesPerView: 1,
          spaceBetween: 10
        },
        // when window width is <= 480px
        480: {
          slidesPerView: 2,
          spaceBetween: 20,
          autoplay: {
          delay: 2500,
          disableOnInteraction: false,
          },
        },
        // when window width is <= 640px
        768: {
          slidesPerView: 3,
          spaceBetween: 30
        },
        992: {
          slidesPerView: 2,
          spaceBetween: 30
        }
    },
    });
    
    var swiper = new Swiper('.khachhang-slider .swiper-container', {
      slidesPerView: 3,
      slidesPerColumn: 2,
      spaceBetween: 30,
      navigation: {
        nextEl: '.swiper-btn-next',
        prevEl: '.swiper-btn-prev'
      },
      
      // autoplay: {
      //   delay: 3000,
      //   disableOnInteraction: false,
      // },
      // If we need pagination
      pagination: {
        el: '.home-slider .swiper-pagination',
        clickable: true,
        type: 'bullets'
      },
      breakpoints: {
        // when window width is <= 320px
        320: {
          slidesPerView: 1,
          spaceBetween: 10
        },
        // when window width is <= 480px
        480: {
        slidesPerView: 2,
        spaceBetween: 20,
        autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
        },
        // when window width is <= 640px
        768: {
          slidesPerView: 3,
          spaceBetween: 30
        },
        992: {
          slidesPerView: 2,
          spaceBetween: 30
        }
    },
    });
    var ProjectSlider = new Swiper(".project-1 .project-list .swiper-container",{
        slidesPerView: 3,
        centeredSlides: true,
        spaceBetween: -600,
        allowTouchMove: false,
        loopedSlides: 6,
        loop: true,
        autoplay: {
          delay: 4500
        },
        speed: 500,
        preventInteractionOnTransition: true,
        navigation: {
          prevEl: ".project-1 .project-list .btn-prev",
          nextEl: ".project-1 .project-list .btn-next"
        },
        pagination: {
          el: ".project-1 .project-list .swiper-pagination",
          clickable: true
        },
        on: {
          slideChange: function() {
            var activeIndex = this.activeIndex;
            var realIndex = this.slides
              .eq(activeIndex)
              .attr("data-swiper-slide-index");
            $(".swiper-slide").removeClass(
              "swiper-slide-nth-prev-2 swiper-slide-nth-next-2"
            );
            $(
              '.swiper-slide[data-swiper-slide-index="' +
                realIndex +
                '"]'
            )
              .prev()
              .prev()
              .addClass("swiper-slide-nth-prev-2");
            $(
              '.swiper-slide[data-swiper-slide-index="' +
                realIndex +
                '"]'
            )
              .next()
              .next()
              .addClass("swiper-slide-nth-next-2");
          },
          init: function() {
            setTimeout(function() {
              $(
                ".project-1 .project-list .swiper-container .swiper-slide .imgbox a"
              ).each(function() {
                $(this).height($(this).width() / (730 / 480));
              });
            }, 800);
          },
          resize: function() {
            setTimeout(function() {
              $(
                ".project-1 .project-list .swiper-container .swiper-slide .imgbox a"
              ).each(function() {
                $(this).height($(this).width() / (730 / 480));
              });
            }, 800);
          }
        },
        breakpoints: {
          1024: {
            spaceBetween: 20
          },
          768: {
            slidesPerView: 1,
            spaceBetween: 20,
            centeredSlides: false
          },
          576: {
            slidesPerView: 1,
            spaceBetween: 20,
            centeredSlides: false
          }
        }
      }
    );
    var galleryThumbs = new Swiper('.gallery-thumbs', {
    slidesPerView: 5,
		spaceBetween: 20,
		speed: 1200,
		loop: true,
		slideToClickedSlide: true,
		centeredSlides: true,
		loopedSlides: 5,
		autoplay: {
			delay: 3200,
			disableOnInteraction: false
		},
		breakpoints: {
			768: {
				slidesPerView: 3
			},
			576: {
				slidesPerView: 4,
				spaceBetween: 10
			}
		},
    });
    var galleryTop = new Swiper('.gallery-top', {
      spaceBetween: 20,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      thumbs: {
        swiper: galleryThumbs
      }
    });
    var swiper = new Swiper(".product-brands .swiper-container", {
      slidesPerView: 5,
      spaceBetween: 0,
      breakpoints: {
        // when window width is <= 480px
        480: {
          slidesPerView: 1,
          spaceBetween: 20
        },
        // when window width is <= 640px
        768: {
          slidesPerView: 2,
          spaceBetween: 30
        },
        992: {
          slidesPerView: 3,
          spaceBetween: 30
        },
        1025: {
          slidesPerView: 4,
          spaceBetween: 30
        }
      }
    });
}
function projectSelect() {
	$("[data-nav]").on("change", function() {
		var selectHref = $(this).val();
		if (selectHref.length > 0) {
			window.location.assign(selectHref);
		}
	});
}

function gotop() {
  $('#gotop').on('click', function() {
      $('html,body').animate({
          scrollTop: 0
      }, 1000)
  })
}

$(document).ready(function() {
  setBackground();
  searchshow();
  swiperInit();
  projectSelect();
  mobileToggle();
  mappingNavigation();
  mappingSearch();
  mapppingLink();
  gotop();
});
// Mapping mobile

function mappingNavigation() {
  return new MappingListener({
    selector: ".navigation-wrapper",
    mobileWrapper: ".mobile-wrapper",
    mobileMethod: "appendTo",
    desktopWrapper: ".header-wrapper-right",
    desktopMethod: "prependTo",
    breakpoint: 1360
  }).watch();
}
function mappingSearch() {
  return new MappingListener({
    selector: ".search-wrapper-temp",
    mobileWrapper: ".mobile-wrapper",
    mobileMethod: "appendTo",
    desktopWrapper: ".language-wrapper",
    desktopMethod: "insertBefore",
    breakpoint: 1025
  }).watch();
}
function mapppingLink() {
  return new MappingListener({
    selector: ".group-link-wrapper",
    mobileWrapper: ".mobile-wrapper",
    mobileMethod: "appendTo",
    desktopWrapper: ".language-wrapper",
    desktopMethod: "insertAfter",
    breakpoint: 1025
  }).watch();
}
//Toggle Search
$(".search-toggle").on("click", function() {
  $(".searchbox").toggleClass("active");
});
